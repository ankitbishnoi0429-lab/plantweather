import os
from flask import Flask, render_template, request, redirect, url_for
import requests
from PIL import Image
import io
import numpy as np

# Optional: if you have a trained Keras model, place it as plant_disease_model.h5
try:
    from tensorflow.keras.models import load_model
    MODEL = None
    if os.path.exists("plant_disease_model.h5"):
        MODEL = load_model("plant_disease_model.h5")
except Exception:
    MODEL = None

API_KEY = "C9Ki53TGyBoWHmyTGMPRF5Qfm2ubpGL1"  # your provided key (used for OpenWeatherMap endpoints)

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 10 * 1024 * 1024  # 10MB upload limit

def get_weather_by_city(city_name):
    url = f"https://api.openweathermap.org/data/2.5/weather"
    params = {"q": city_name, "appid": API_KEY, "units": "metric"}
    r = requests.get(url, params=params, timeout=10)
    r.raise_for_status()
    return r.json()

def analyze_image_simple(image_bytes):
    # Simple heuristic: detect yellow/brown spot area percentage
    im = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    im = im.resize((300,300))
    arr = np.array(im).astype(int)
    R,G,B = arr[:,:,0], arr[:,:,1], arr[:,:,2]
    # heuristic mask for brown/yellow-ish pixels
    brown_mask = ((R > 100) & (G > 60) & (B < 100)) | ((R>120)&(G>90)&(B<80))
    yellow_mask = ((R > 160) & (G > 140) & (B < 100))
    suspect = np.logical_or(brown_mask, yellow_mask)
    percent = suspect.sum() / (suspect.shape[0]*suspect.shape[1]) * 100
    # prepare response
    if percent < 1.5:
        return {"label":"Healthy (no obvious spots detected)","confidence": round(100-percent,1), "percent_spots": round(percent,2)}
    else:
        # give a guessed disease name based on colors (very rough)
        if percent > 20:
            disease = "Severe leaf spot / blight (suspected)"
        elif percent > 5:
            disease = "Leaf spot / early blight (suspected)"
        else:
            disease = "Minor spotting (suspected)"
        return {"label":disease,"confidence": round(100-percent,1), "percent_spots": round(percent,2)}

@app.route("/", methods=["GET","POST"])
def index():
    return render_template("index.html")

@app.route("/analyze", methods=["POST"])
def analyze():
    city = request.form.get("city")
    file = request.files.get("plant_image")
    weather = None
    weather_error = None
    weather_coords = None
    try:
        if city:
            data = get_weather_by_city(city)
            weather = {
                "city": data.get("name"),
                "temp": data["main"]["temp"],
                "desc": data["weather"][0]["description"].title(),
                "lat": data["coord"]["lat"],
                "lon": data["coord"]["lon"]
            }
            weather_coords = (weather["lat"], weather["lon"])
    except Exception as e:
        weather_error = str(e)

    analysis = None
    image_preview = None
    if file:
        img_bytes = file.read()
        image_preview = "data:" + file.content_type + ";base64," + (img_bytes.encode("base64") if False else "")
        # note: creating a base64 string in Python without imports is longer; instead save temporary file path to show
        # We'll save uploaded image to static/uploads for result display
        uploads_dir = os.path.join("static","uploads")
        os.makedirs(uploads_dir, exist_ok=True)
        fname = "uploaded_plant.jpg"
        path = os.path.join(uploads_dir, fname)
        with open(path, "wb") as f:
            f.write(img_bytes)
        # If a Keras model exists, you can run it here (MODEL) - omitted by default
        if MODEL is not None:
            try:
                from tensorflow.keras.preprocessing import image
                img = Image.open(io.BytesIO(img_bytes)).resize((224,224)).convert("RGB")
                x = np.array(img)/255.0
                x = np.expand_dims(x,0)
                preds = MODEL.predict(x)[0]
                top_idx = int(np.argmax(preds))
                # Without a labels file, we show generic output
                analysis = {"label":f"Model predicted class #{top_idx}","confidence":float(preds[top_idx])}
            except Exception as e:
                analysis = {"label":"Model error","confidence":0.0, "error":str(e)}
        else:
            analysis = analyze_image_simple(img_bytes)
        # set preview path for template
        image_preview = "/" + path.replace("\\","/")
    return render_template("result.html", weather=weather, weather_error=weather_error, analysis=analysis, image_preview=image_preview, coords=weather_coords)

if __name__ == "__main__":
    app.run(debug=True)
